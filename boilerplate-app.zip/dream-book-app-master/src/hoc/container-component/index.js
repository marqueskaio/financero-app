import {View} from "react-native";

export const ContainerComponent = ({children}) => {
  return (
    <View>
      {children}
    </View>
  )
}